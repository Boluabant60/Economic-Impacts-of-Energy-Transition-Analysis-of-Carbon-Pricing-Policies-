# SEE_Energy_Transition_Code

This repository contains R code for panel data analysis on the impact of renewable energy and carbon pricing on CO₂ emissions in Southeastern Europe.

## Files
- SEE_panel.R: Main R code for all analyses (regression, robustness, Granger, Arellano-Bond).
- SEE_panel.csv: Sample template for your panel data (country-year-variables).

## Usage
1. Fill your data in the SEE_panel.csv template (see header).
2. Open SEE_panel.R in RStudio or your R environment.
3. Install required packages if needed.
4. Run the code chunk by chunk for full replication.

## Contact
Prepared by: GelisimEnstitusu (2025)
